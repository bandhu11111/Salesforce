// accountListLWC.js
import { LightningElement, wire, track } from 'lwc';
import getAccounts from '@salesforce/apex/AccountController.getAccounts';
import updateAccount from '@salesforce/apex/AccountController.updateAccount';
import deleteAccount from '@salesforce/apex/AccountController.deleteAccount';

export default class AccountListLWC extends LightningElement {
    @track accounts;

    @wire(getAccounts) 
    wiredAccounts({ error, data }) {
        if (data) {
            this.accounts = data;
        } else if (error) {
            console.error('Error fetching accounts:', error);
        }
    }

    handleEdit(event) {
        const accountId = event.target.dataset.id;
        const newName = prompt('Enter a new name:');
        if (newName) {
            updateAccount({ accountId, newName })
                .then(() => {
                    this.refreshData();
                })
                .catch(error => {
                    console.error('Error updating account:', error);
                });
        }
    }

    handleDelete(event) {
        const accountId = event.target.dataset.id;
        if (confirm('Are you sure you want to delete this account?')) {
            deleteAccount({ accountId })
                .then(() => {
                    this.refreshData();
                })
                .catch(error => {
                    console.error('Error deleting account:', error);
                });
        }
    }

    refreshData() {
        return refreshApex(this.accounts);
    }
}