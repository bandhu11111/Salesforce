import { LightningElement ,api} from 'lwc';

export default class SampleDemo extends LightningElement {
    buttonClicked = false;
    @api username = '';
    @api password = '';
    handleUsername(event)
    {
        this.username = this.event.value;
    }

    handlePassword(event)
    {
        this.password= this.event.value;
    }
    
    handleClick(event){
        this.buttonClicked =true;
        //console.log(this.template.querySelector('lightning-input/'))
        this.template.querySelector('c-sample-click').showUserDetails(this.username, this.password)
    }
}