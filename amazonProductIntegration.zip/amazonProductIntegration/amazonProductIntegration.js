import { LightningElement } from 'lwc';

export default class AmazonProductIntegration extends LightningElement {}