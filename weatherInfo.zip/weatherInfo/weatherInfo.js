import { LightningElement, wire, track } from 'lwc';
import getTemp from '@salesforce/apex/weatherInfo.getTemp';

const CITIES = [
    { label: 'jaipur', value: 'jaipur' },
    { label: 'jamanali', value: 'jamanali' },
    { label: 'mumbai', value: 'mumbai' }
];

export default class WeatherInfo extends LightningElement {
    cities = CITIES;
    city = 'jaipur'; // Set default city

    @track tempData = {};
    @track location = {};
    @track current = {};
    @track condition = {};

    @wire(getTemp, { city: '$city' })
    getData({ data, error }) {
        if (data) {
            console.log('data', data);
            this.tempData = JSON.parse(data);
            this.location = this.tempData.location;
            this.current = this.tempData.current;
            this.condition = this.tempData.current.condition;
            console.log('tempData', this.tempData);
        } else if (error) {
            console.log('error', error);
        }
    }

    handleCity(event) {
        this.city = event.target.value;
    }
}
