import { LightningElement, track, wire } from 'lwc';

 

import getAccountList from '@salesforce/apex/AccountDataController.getAccountList';

import { updateRecord } from 'lightning/uiRecordApi';

import Account_Name from '@salesforce/schema/Account.Name';

import Account_Id from '@salesforce/schema/Account.Id';

import Account_Industry from '@salesforce/schema/Account.Industry';

import Account_Description from '@salesforce/schema/Account.Description';

import {ShowToastEvent} from 'lightning/platformShowToastEvent';

 

import {refreshApex} from '@salesforce/apex';

 

const actions = [

 

    { label: 'Edit', name: 'Edit' },

 

];

 

const columns=[

{label: 'Account Name', fieldName: 'Name'},

{label: 'Account Industry', fieldName: 'Industry',editable: true},

{label: 'Account Description', fieldName: 'Description',editable: true},

{label: 'Parent Account Name', fieldName: 'Parent_Account_Name'},

{

    type: 'action',

    typeAttributes: { rowActions: actions },

},

];

 

export default class TestLWCTableExample extends LightningElement {

 

    @track error;

 

    @track columns = columns;

 

    @track actions = actions;

 

    @track accList;

    @track isShowModal = false;

    @track isEditRecord = false;

    @track recordIdToEdit;

 

 

    @track showLoadingSpinner = false;

    draftValues = [];

 

    refreshTable;

 

    @wire (getAccountList) accList(result)

 

    {

 

        this.refreshTable = result;

 

        if(result.data)

 

        {

            let accParsedData=JSON.parse(JSON.stringify(result.data));

            let baseUrlOfOrg= 'https://'+location.host+'/';

            accParsedData.forEach(acc => {

                if(acc.ParentId){

                acc.Parent_Account_Name=acc.Parent.Name;

               // acc.Account_URL=baseUrlOfOrg+acc.Id;

                }

            });

          //  this.refreshTable = accParsedData;

            this.accList = accParsedData;

        }

        else if(result.error)

        {

            this.error = result.error;

        }

    }

 

    handleRowAction(event) {

 

        const actionName = event.detail.action.name;

 

        const row = event.detail.row;

 

        switch (actionName) {

            case 'Edit':

                this.editRecord(row.Id);

                break;

            default:

        }

 

    }

 

    editRecord(recordIdDetail) {

        this.isShowModal = true;

        this.isEditRecord = true;

        this.recordIdToEdit=recordIdDetail;

 

    }

    hideModalBox() { 

        this.isShowModal = false;

    }

    handleSubmit(event){

     

        this.isShowModal = false;

        const evt = new ShowToastEvent({

            title: 'Success Message',

            message: 'Record Updated successfully ',

            variant: 'success',

            mode:'dismissible'

        });

        this.dispatchEvent(evt);

       

    }

    handleSuccess(event){

        return refreshApex(this.refreshTable); 

    }

 

}