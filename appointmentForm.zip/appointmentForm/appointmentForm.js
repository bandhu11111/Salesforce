import { LightningElement } from 'lwc';

export default class AppointmentForm extends LightningElement {
    handleSuccess(event) {
        // Handle successful form submission
        const toastEvent = new ShowToastEvent({
            title: 'Success',
            message: 'Appointment created successfully!',
            variant: 'success'
        });
        this.dispatchEvent(toastEvent);

        // You can perform additional actions, e.g., navigating to a record page
        // const recordId = event.detail.id;
        // this[NavigationMixin.Navigate]({
        //     type: 'standard__recordPage',
        //     attributes: {
        //         recordId: recordId,
        //         objectApiName: 'Appointment__c',
        //         actionName: 'view'
        //     }
        // });
    }
}
