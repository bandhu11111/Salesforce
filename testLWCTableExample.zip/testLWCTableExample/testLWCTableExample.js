import { LightningElement, track, wire } from 'lwc';
import getAccountList from '@salesforce/apex/AccountDataControllerdel.getAccountList';
import deleteSelectedAccount from '@salesforce/apex/AccountDataControllerdel.deleteSelectedAccount';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
const actions = [
    { label: 'Show details', name: 'show_details' },
    { label: 'Delete', name: 'delete' },

];

const columns=[

{label: 'Account Name', fieldName: 'Name'},{label: 'Account Industry', fieldName: 'Industry'},
{label: 'Account Description', fieldName: 'Description'},
{label: 'Parent Account Name', fieldName: 'Parent_Account_Name'},
{
    type: 'action',
    typeAttributes: { rowActions: actions },
},
];
export default class TestLWCTableExample extends LightningElement {
    @track error;
    @track columns = columns;
    @track actions = actions;
    @track accList;
    @track showLoadingSpinner = false;
    refreshTable;
    @wire (getAccountList) accList(result)
    {
        this.refreshTable = result;
        if(result.data)
        {        

            let accParsedData=JSON.parse(JSON.stringify(result.data));
            let baseUrlOfOrg= 'https://'+location.host+'/';
            accParsedData.forEach(acc => {
                if(acc.ParentId){
                acc.Parent_Account_Name=acc.Parent.Name;
             
                }
            });
        
            this.accList = accParsedData;
        }
        else if(result.error)
        {
            this.error = result.error;
        }   
    }
    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                this.handleDeleteRow(row.Id);
                break;
            case 'show_details':
                this.showRecordDetails(row.Id);
                break;
            default:
        }
    }
    handleDeleteRow(recordIdToDelete) {
        this.showLoadingSpinner = true;
        deleteSelectedAccount({recordIdToDelete:recordIdToDelete})
        .then(result =>{
            this.showLoadingSpinner = false;
            const evt = new ShowToastEvent({
                title: 'Success Message',
                message: 'Record deleted successfully ', 
                variant: 'success', 
                mode:'dismissible'  

            }); 
            this.dispatchEvent(evt);
           return refreshApex(this.refreshTable);
        } )
        .catch(error => {
            this.error = error;
        });
    }
    showRecordDetails(recordIdDetail) {    

    }
}